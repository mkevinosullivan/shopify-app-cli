module ShopifyCli
  VERSION = '0.0.2'
end