require "test_helper"
require_relative "test_helpers"

ShopifyCli::ProjectType.load_type(:script)
