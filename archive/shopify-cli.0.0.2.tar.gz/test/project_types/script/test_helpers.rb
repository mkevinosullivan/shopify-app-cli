module TestHelpers
  autoload :FakeScriptProject, 'project_types/script/test_helpers/fake_script_project'
end
